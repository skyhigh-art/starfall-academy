# Starfall Academy
A celestial-gothic school roleplay starter.

## Run locally
Install Node.js 18+, then run `npm install` and `npm run dev`.

## Deploy
Import this repository into Vercel. Select Vite, build command `npm run build`, output directory `dist`.

## Current version
This is a scripted Demo Mode, not a live AI connection. Chat saves in localStorage on this browser/device. No API key is required. Cloud sync and AI chat are not connected yet.

The player controls Astra Draco. The demo does not invent Astra's actions or dialogue.
